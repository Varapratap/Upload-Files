package com.example.uploadfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadFilesApplication.class, args);
		System.out.println("BCBM Assignments");
	}

}
